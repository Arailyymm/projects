import os
import datetime
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.optimizers import Adam
from sklearn.metrics import confusion_matrix
from tensorflow.keras.models import Sequential
from sklearn.metrics import classification_report
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
from tensorflow.keras.regularizers import l2
from tensorflow.keras.applications import VGG16  # Import VGG16

# Initialize the number of training epochs, batch size, and other parameters
num_epochs = 35
batch_size = 32
input_size = (224, 224)  # Input size for VGG16
num_classes = 6
lr = 0.00001

# Define the paths to the directories containing the training, validation, and testing data
TRAIN_PATH = os.path.sep.join(["/data2/arai/SCI/dataset/aug_cassava_data_new/new/", "training"])
VAL_PATH = os.path.sep.join(["/data2/arai/SCI/dataset/aug_cassava_data_new/new/", "validation"])
TEST_PATH = os.path.sep.join(["/data2/arai/SCI/dataset/aug_cassava_data_new/new/", "testing"])

# Initialize the data augmentation objects
trainAug = ImageDataGenerator(
    rotation_range=20,
    zoom_range=0.01,
    width_shift_range=0.01,
    height_shift_range=0.01,
    shear_range=0.01,
    horizontal_flip=True,
    vertical_flip=True,
    fill_mode="nearest")

valAug = ImageDataGenerator()
testAug = ImageDataGenerator()

# Initialize the data generators for training, validation, and testing
trainGen = trainAug.flow_from_directory(
    TRAIN_PATH,
    target_size=input_size,
    color_mode='rgb',
    batch_size=batch_size,
    class_mode='categorical',
    shuffle=True)

valGen = valAug.flow_from_directory(
    VAL_PATH,
    target_size=input_size,
    color_mode='rgb',
    batch_size=batch_size,
    class_mode='categorical',
    shuffle=False)

testGen = testAug.flow_from_directory(
    TEST_PATH,
    target_size=input_size,
    color_mode='rgb',
    batch_size=batch_size,
    class_mode='categorical',
    shuffle=False)

# Create a VGG16 base model
base_model = VGG16(weights='imagenet', include_top=False, input_shape=(input_size[0], input_size[1], 3))

# Build the custom model on top of VGG16
model = Sequential()
model.add(base_model)
model.add(GlobalAveragePooling2D())
model.add(Dense(512, activation="relu"))
#model.add(Dense(256, activation="relu"))
model.add(Dropout(0.2))
model.add(Dense(num_classes, activation="softmax"))

model.summary()

# Compile the model
opt = Adam(learning_rate=lr)
model.compile(loss='categorical_crossentropy', optimizer=opt, metrics=["accuracy"])

# Train the model
start_time = datetime.datetime.now()
history = model.fit_generator(
    trainGen,
    steps_per_epoch=len(trainGen),
    validation_data=valGen,
    validation_steps=len(valGen),
    epochs=num_epochs)

# Plot accuracy and loss
print(history.history.keys())
plt.plot(history.history['accuracy'], 'o-')
plt.plot(history.history['val_accuracy'], 'x-')
plt.title('VGG16')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend(['Training', 'Validation'], loc=0)
plt.savefig("/data2/arai/SCI/dataset/aug_cassava_data_new/new/outt/VGG16_Accuracy.png")
plt.show()

plt.plot(history.history['loss'], 'o-')
plt.plot(history.history['val_loss'], 'x-')
plt.title('VGG16')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['Training', 'Validation'], loc=0)
plt.savefig("/data2/arai/SCI/dataset/aug_cassava_data_new/new/outt/VGG16_Loss.png")
plt.show()

# Make predictions and calculate the confusion matrix and classification report
y_pred = model.predict(testGen)
y_pred = np.argmax(y_pred, axis=1)
target_names = ["crm", "cmd", "cgm", "cbsd", "cbls","healthy"]

cm = confusion_matrix(y_pred, testGen.classes)

print("***** Confusion Matrix *****")
for i, target_name in enumerate(target_names):
    print(f"{target_name}: {cm[i]}")

print("***** Classification Report *****")
print(classification_report(y_pred, testGen.classes, target_names=target_names))

# Save the model
model.save("/data2/arai/SCI/dataset/aug_cassava_data_new/new/outt/VGG16.h5")

# Evaluate the model on the test set
loss, accuracy = model.evaluate(testGen)
print("Test Loss: {:.2f}".format(loss))
print("Test Accuracy: {:.2f}%".format(accuracy * 100))
