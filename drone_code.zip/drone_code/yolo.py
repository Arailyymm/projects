import ultralytics
from ultralytics import YOLO

from IPython.display import display, Image


# Load a model


#model = YOLO("yolov8l.yaml")  # build a new model from scratch

model = YOLO("/data2/arai/drone/runs/detect/train/weights/best.pt")  # load a pretrained model (recommended for training)

# Use the model
#model.train(data="/data2/arai/drone/data.yaml", batch=4, epochs=10, device=[0])  # train the model
#metrics = model.val()  # evaluate model performance on the validation set
results = model("/data2/arai/drone/data_test/train/images/5.jpg")  # predict on an image
print(results)