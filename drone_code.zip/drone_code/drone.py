import os
import xml.etree.ElementTree as ET

def convert_coordinates(size, box):
    dw = 1.0 / size[0]
    dh = 1.0 / size[1]
    x = (box[0] + box[1]) / 2.0
    y = (box[2] + box[3]) / 2.0
    w = box[1] - box[0]
    h = box[3] - box[2]
    x = x * dw
    w = w * dw
    y = y * dh
    h = h * dh
    return (x, y, w, h)

def convert_annotation(xml_path, output_path):
    tree = ET.parse(xml_path)
    root = tree.getroot()

    image_name = root.find('filename').text
    image_width = int(root.find('size/width').text)
    image_height = int(root.find('size/height').text)

    txt_file_path = os.path.join(output_path, image_name.replace('.jpg', '.txt'))
    with open(txt_file_path, 'w') as f:
        for obj in root.findall('object'):
            class_name = obj.find('name').text
            if class_name != 'drone':  # Considering only 'drone' class
                continue
            class_index = 0  # Replace 'drone' with index 0
            box = obj.find('bndbox')
            xmin = int(box.find('xmin').text)
            ymin = int(box.find('ymin').text)
            xmax = int(box.find('xmax').text)
            ymax = int(box.find('ymax').text)

            b = (xmin, xmax, ymin, ymax)
            bb = convert_coordinates((image_width, image_height), b)

            f.write(f"{class_index} {' '.join([str(a) for a in bb])}\n")

# Example usage
xml_folder = "/data2/arai/drone/xml/"
output_folder = "/data2/arai/drone/out_xml/"

for xml_file in os.listdir(xml_folder):
    if xml_file.endswith('.xml'):
        xml_path = os.path.join(xml_folder, xml_file)
        convert_annotation(xml_path, output_folder)
